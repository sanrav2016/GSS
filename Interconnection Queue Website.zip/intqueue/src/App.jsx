import { useState } from 'react'
import './App.css'
import Navbar from "./NavBar.jsx";
import Home from "./pages/Home.jsx";
import Information from "./pages/Information.jsx";
import SubmitForm from "./pages/SubmitForm.jsx";
import { Route, Routes } from "react-router-dom";

function App() {
    return (
       <>
       <Navbar />
       <div className="container">
           <Routes>
               <Route path="/" element={<Home />}/>
               <Route path="/information" element={<Information />}/>
               <Route path="/submitForm" element={<SubmitForm />}/>
           </Routes>
       </div>
       </>
    )
}

export default App