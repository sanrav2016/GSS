export default function Information() {
    return <h1>Information</h1>
}