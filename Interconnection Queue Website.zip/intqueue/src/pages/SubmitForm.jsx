export default function SubmitForm() {
    return <h1>Submit a Form</h1>
}